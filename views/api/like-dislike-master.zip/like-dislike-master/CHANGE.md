Change Log: `like-dislike`
===================================

## Version 1.0.0

**Date:** 2-Feb-2016

Initial release.

1. Added the callback functions: `click` and `beforeClick`.
2. Added ability to cancel a call the callback function `click`.
3. Added the method `readOnly` to lock and unlock buttons.